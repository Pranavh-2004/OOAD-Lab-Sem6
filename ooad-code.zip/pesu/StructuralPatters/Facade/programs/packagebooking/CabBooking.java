interface CabBooking
{
	void book();
}