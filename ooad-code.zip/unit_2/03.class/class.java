class Student
{
    int SRN;
    String name;
    char section;
    boolean status;

    Student() {
    }

    Student(int _SRN) {
        SRN = _SRN;
    }

    Student(int _SRN, String _name) {
        SRN = _SRN;
        name = _name;
    }

    Student(int _SRN, String _name, char _section) {
        SRN = _SRN;
        name = _name;
        section = _section;
    }

    Student(int _SRN, String _name, char _section, boolean _status) {
        SRN = _SRN;
        name = _name;
        section = _section;
        status = _status;
    }

    void display() {
        System.out.println("SRN = " + SRN);
        System.out.println("name = " + name);
        System.out.println("section = " + section);
        System.out.println("status = " + status);
        System.out.println();
    }

    public String toString() {
        return String.valueOf(SRN);
    }
}

class Class
{
    public static void main(String args[]) {
        Student s1 = new Student();
        s1.display();

        s1.SRN = 1;
        s1.name = "Student1";
        s1.section = 'G';
        s1.status = true;

        s1.display();

        Student s2 = s1;
        s2.SRN = 2;

        s2.display();
        s1.display();

        Student s3 = new Student(3);
        s3.display();

        Student s4 = new Student(4, "Student 3");
        s4.display();

        Student s5 = new Student(5, "Student 4", 'G');
        s5.display();

        Student s6 = new Student(6, "Student 5", 'G', true);
        s6.display();

        System.out.println(s6);
    }
}
